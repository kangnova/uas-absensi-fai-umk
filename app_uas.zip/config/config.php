<?php
// Base URL configuration
define('BASE_URL', 'http://localhost/uas-absensi-fai-umk/public/');

// Set timezone
date_default_timezone_set('Asia/Jakarta');

// Error reporting (disable for production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>
